'use strict';
const request = require('request');

module.exports.hello = (event, context, callback) => {
  const response = {
    statusCode: 200,
    body: JSON.stringify({
      message: 'Go Serverless v1.0! Your function executed successfully!',
      input: event,
    }),
  };

  callback(null, response);

  // callback(null, { message: 'Go Serverless v1.0! Your function executed successfully!', event });
};

module.exports.getAllStories = (event, context, callback) => {
  //key = a9ce77430032f94b49e35446c5587c85
  //token = 2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f
  //usernameOrID = bennymohan
  //https://api.trello.com/1/members/bennymohan/boards?key=a9ce77430032f94b49e35446c5587c85&token=2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f
  request.get('https://api.trello.com/1/boards/BwXA7ZZT/cards/all?key=a9ce77430032f94b49e35446c5587c85&token=2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f', function (error, response, body) {
    var data = [];
    var hh = JSON.parse(body);
    for (var i in hh) {
      data.push('{"name" : '+ '"'+ hh[i].name+'"' + ', "id" : '+ '"'+ hh[i].id+'"}' );
    }

    response = {
      statusCode: 200,
      body: JSON.stringify({
       data
      }),
    };
    console.log(body);
    callback(null,response);
  });
};

module.exports.getAllProjects = (event, context, callback) => {
  //key = a9ce77430032f94b49e35446c5587c85
  //token = 2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f
  //usernameOrID = bennymohan
  //https://api.trello.com/1/members/bennymohan/boards?key=a9ce77430032f94b49e35446c5587c85&token=2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f
  request.get('https://api.trello.com/1/members/bennymohan/boards?key=a9ce77430032f94b49e35446c5587c85&token=2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f', function (error, response, body) {
    var data = [];
    var hh = JSON.parse(body);
    for (var i in hh) {
      var project = {};
      project.name =  hh[i].name;
      project.id = hh[i].id;
      data.push(project);
    }

    response = {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify({
       data
      }),
    };
    console.log(body);
    callback(null,response);
  });
};


module.exports.getAllBoardsByProject = (event, context, callback) => {
  //key = a9ce77430032f94b49e35446c5587c85
  //token = 2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f
  //usernameOrID = bennymohan
  //https://api.trello.com/1/members/bennymohan/boards?key=a9ce77430032f94b49e35446c5587c85&token=2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f
  request.get('https://api.trello.com/1/boards/5a85c18231ab0928c5d0c3ea/lists?key=a9ce77430032f94b49e35446c5587c85&token=2ba1977dfaf9099a0c5a85ea7226437d9295bc190e5d8644a25927a749bd414f&cards=open&card_fields=name&filter=open&fields=name', function (error, response, body) {
    var data = [];
    var cards = [];
    var hh = JSON.parse(body);
    for (var i in hh) {
      cards = [];
      var project = {};
      project.name =  hh[i].name;
      project.id = hh[i].id;
      
      for (var a in hh[i].cards){
        var userStories = {}
        userStories.name = hh[i].cards[a].name;
        userStories.id =  hh[i].cards[a].id;
        cards.push(userStories);
      }
      project.cards = cards;
      data.push(project);
    }

    response = {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify({
       data
      }),
    };
    console.log(body);
    callback(null,response);
  });
};